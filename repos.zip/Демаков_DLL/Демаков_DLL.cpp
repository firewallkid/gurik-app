﻿#include "pch.h"
#include "math.h"
#include "Демаков_DLL.h"


using namespace System;
using namespace System::Windows::Forms;

namespace Демаков_DLL
{		
	double Class1::Vvod(TextBox^ t)
	{
		return Convert::ToDouble(t->Text);
	}
	void Class1::Vivod(double x, TextBox^ t)
	{
		t->Text = Convert::ToString(x);
	}
	double Class1::Formula_Return(double x, double y, double c)
	{
		c = Math::Round(x * log10(x - 6) - sin(pow(x, 2)) / y * x * x * x, 3);
		return c;
	}
	void Class1::Formula_Void(double x, double y, double& result)
	{
	result = Math::Round(x * log10(x - 6) - sin(pow(x, 2)) / (y * x * x * x), 3);
	}
	double Class1::Find_l(double a, double x, double y, double l)
	{
		if ((x + y) < 2 && (x + y) > -2)
		{
			double min = pow(sin(a * x), 2);
			if (min > pow(cos(x), 2))
			{
				min = pow(cos(x), 2);
			}
			if (min > y + x)
			{
				min = y + x;
			}
			l = Math::Round(min, 3);
			MessageBox::Show("Первая ветвь", "Информация",MessageBoxButtons::OK);
		}
		else if (x + y <= -2)
		{
			l = 1;
			MessageBox::Show("Вторая ветвь", "Информация", MessageBoxButtons::OK);
		}
		else 
		{
			double max = y;
			if (max < sqrt(fabs(a + x)))
			{
				max = sqrt(fabs(a + x));
			}
			if (max < log(fabs(y * x)))
			{
				max = log(fabs(y * x));
			}
			l = Math::Round(max, 3);
			MessageBox::Show("Третья ветвь", "Информация", MessageBoxButtons::OK);
		}
		return l;
	}
	void Class1::verification(System::Windows::Forms::KeyPressEventArgs^ e, TextBox^ textBox)
	{
		if (!((e->KeyChar >= '0' && e->KeyChar <= '9') || e->KeyChar == ',' || e->KeyChar == '\b' || e->KeyChar == '-'))
		{
			e->Handled = true;
		}
	}
}

