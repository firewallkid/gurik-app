﻿#pragma once

using namespace System;
using namespace System::Windows::Forms;

namespace Демаков_DLL {
	public ref class Class1
	{
		// TODO: Добавьте сюда свои методы для этого класса.
	public:
		static double Vvod(TextBox^ t);
		static void Vivod(double x, TextBox^ t);
		static double Formula_Return(double x, double y, double c);
		static void Formula_Void(double x, double y, double& result);
		static double Find_l(double a, double x, double y, double l);
		static void verification(System::Windows::Forms::KeyPressEventArgs^ e, TextBox^ textBox);
	};
}
