﻿#include "pch.h"
#include "math.h"
#include "Демаков_DLL1.h"


using namespace System;
using namespace System::Windows::Forms;

namespace Демаков_DLL1
{
	double Class1::Vvod(TextBox^ t)
	{
		return Convert::ToDouble(t->Text);
	}
	void Class1::Vivod(double x, TextBox^ t)
	{
		t->Text = Convert::ToString(x);
	}
	void Class1::verification(System::Windows::Forms::KeyPressEventArgs^ e, TextBox^ textBox)
	{
		if (!((e->KeyChar >= '0' && e->KeyChar <= '9') || e->KeyChar == ',' || e->KeyChar == '\b' || e->KeyChar == '-'))
		{
			e->Handled = true;
		}
	}
	void Class1::VivodDGV(double x, double Y, DataGridView^ DGV)
	{
		DGV->Rows->Add(x.ToString("F2"), Y.ToString("F5"));
	}
	double Class1::function(double x, double a)
	{
		double Y;
		if (x <= -6 * a)
		{
			Y = -pow((x + 3 * a), 2) - 2 * a;
		}
		else
		{
			Y = a * cos(x + 3 * a) - 3 * a;
		}
		return Y;
	}
	void Class1::FuncTabulation(double X1, double dx, double a, DataGridView^ DGV, double& summa, double& pr, int& count)
	{
		double x = X1;
		summa = 0;
		pr = 1;
		count = 0;
		int n = Convert::ToInt32(Math::Round((a - X1) / dx + 1));
		for (int i = 1; i <= n; i++)
		{
			double Y = Math::Round(Class1::function(x, a), 5);
			Class1::VivodDGV(x, Y, DGV);
			x += dx;
			if (Y > 0)
			{
				summa += Y;
				pr *= Y;
				count += 1;
			}
		}
		if (count == 0)
		{
			pr = summa = 0;
		};
	}


	double Class1::calculate_side(int n, double R)
	{
		double a = 2 * R * sin(Math::PI / n);
		return a;
	};
	double Class1::calculate_r(int n, double R)
	{
		double r = R * cos(Math::PI / n);
		return r;
	};
	double Class1::calculate_area(int n, double R)
	{
		double S = 0.5 * calculate_side(n, R) * n * calculate_r(n, R);
		return S;
	};
	void Class1::calculate_result(double R, double& n10, double& n50, double& n100)
	{
		n10 = Демаков_DLL1::Class1::calculate_area(10, R);
		n50 = Демаков_DLL1::Class1::calculate_area(50, R);
		n100 = Демаков_DLL1::Class1::calculate_area(100, R);
	};

	double Class1::func(double x)
	{
		double f = pow(x, 5) - x - 1;
		return f;
	}
	double Class1::proiz(double x)
	{
		double p = 5 * pow(x, 4) - 1;
		return p;
	}
	void Class1::find_x(double max_iter, double eps, double a,  double b, double f, double p, double& result, DataGridView^ DGV)
	{
		if (a < b) {
			int i = 0;
			double x = (a + b) / 2;
			f = func(x);
			p = proiz(x);
			while (fabs(f / p) >= eps && max_iter >= i) {
				i++;	
				Class1::VivodDGV1(i, x, f, p, DGV);
				x = x - f / p;
				f = func(x);	
				p = proiz(x);
			};
			result = x;
		}
		else
		{
			MessageBox::Show("Начало интервало должно быть меньше конца!", "Ошибка!", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	};
	void Class1::VivodDGV1(double i, double x, double f, double p, DataGridView^ DGV)
	{
		DGV->Rows->Add(i.ToString("F1"), x.ToString("F2"), f.ToString("F3"), p.ToString("F4"));
	};
}

