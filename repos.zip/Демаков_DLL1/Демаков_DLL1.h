﻿#pragma once

using namespace System;
using namespace System::Windows::Forms;

namespace Демаков_DLL1 {
	public ref class Class1
	{
		// TODO: Добавьте сюда свои методы для этого класса.
	public:
		static double Vvod(TextBox^ t);
		static void Vivod(double x, TextBox^ t);
		static void verification(System::Windows::Forms::KeyPressEventArgs^ e, TextBox^ textBox);
		static void VivodDGV(double x, double Y, DataGridView^ DGV);
		static double function(double x, double a);
		static void FuncTabulation(double X1, double dx, double a, DataGridView^ DGV, double& summa, double& pr, int& count);
		static double calculate_side(int n, double R);
		static double calculate_r(int n, double R);
		static double calculate_area(int n, double R);
		static void calculate_result(double R, double& n10, double& n50, double& n100);
		static double func(double x);
		static double proiz(double x);
		static void find_x(double max_iter, double eps, double a, double b, double f, double p, double& result, DataGridView^ DGV);
		static void VivodDGV1(double i, double x, double f, double p, DataGridView^ DGV);

	};
	
}
